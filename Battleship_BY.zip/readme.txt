JSON is used on the login page in a small example of how the JSON files can be parsed 
we use it to populate the small 3x3 grids with different information for hits (fire), misses(splash of water), and pieces
(so far just black squares).  
It is also used to display the turn at the last "save" state, and the "health" (amount of hits necessary to win) of both players.  