Necessary files for the project to run:
view.js (handles all view type things, things the player will see, as well as game init)
game_state.js (handles all storage of game state things like pieces and hits/misses
html.html (the actual html file that all of this runs in)
style.css (handles all style of the html page)
documentation.html (explanation file of how things were implemented, only for class, will delete after submission)

everything else is non essential/unecessary/can be deleted


Also this file shows up on github
